@extends('layouts.app')

@section('content')
<div class="py-6">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 bg-white border-b border-gray-200">
                <div class="flex items-center justify-between mb-6">
                    <h2 class="text-2xl font-bold text-gray-900">
                        <i class="fas fa-user-graduate mr-2"></i>
                        Student Dashboard
                    </h2>
                    <a href="{{ route('student.profile') }}" class="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                        <i class="fas fa-user-edit mr-2"></i>
                        Edit Profile
                    </a>
                </div>
                
                <!-- Student Profile Section -->
                <div class="mb-8 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-6">
                    <div class="flex items-center space-x-6">
                        <div class="flex-shrink-0">
                            @if(Auth::user()->profile_picture)
                                <img src="{{ asset('storage/' . Auth::user()->profile_picture) }}" alt="Profile Picture" class="w-20 h-20 rounded-full border-4 border-white shadow-lg object-cover">
                            @else
                                <div class="w-20 h-20 rounded-full bg-blue-500 flex items-center justify-center border-4 border-white shadow-lg">
                                    <i class="fas fa-user text-white text-2xl"></i>
                                </div>
                            @endif
                        </div>
                        <div class="flex-1">
                            <h3 class="text-xl font-semibold text-gray-900 mb-2">Welcome, {{ Auth::user()->name }}!</h3>
                            <div class="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm">
                                <div>
                                    <span class="text-gray-600">Student ID:</span>
                                    <span class="font-medium text-gray-900 block">{{ Auth::user()->student_id }}</span>
                                </div>
                                @if(Auth::user()->year_level)
                                <div>
                                    <span class="text-gray-600">Year Level:</span>
                                    <span class="font-medium text-gray-900 block">{{ Auth::user()->year_level }}</span>
                                </div>
                                @endif
                                @if(Auth::user()->section)
                                <div>
                                    <span class="text-gray-600">Section:</span>
                                    <span class="font-medium text-gray-900 block">{{ Auth::user()->section }}</span>
                                </div>
                                @endif
                                @if(Auth::user()->student_type)
                                <div>
                                    <span class="text-gray-600">Student Type:</span>
                                    <span class="font-medium text-gray-900 block capitalize">{{ Auth::user()->student_type }}</span>
                                </div>
                                @endif
                                <div>
                                    <span class="text-gray-600">Email:</span>
                                    <span class="font-medium text-gray-900 block">{{ Auth::user()->email }}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="mb-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Attendance Summary</h3>
                    <p class="text-gray-600">Here's your attendance summary across all subjects.</p>
                </div>

                <!-- Attendance Code Input Form -->
                <div class="mb-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
                    <h3 class="text-lg font-medium text-blue-900 mb-4">
                        <i class="fas fa-qrcode mr-2"></i>
                        Mark Attendance
                    </h3>
                    <p class="text-blue-700 mb-4">Enter the attendance code provided by your teacher to mark your attendance.</p>
                    
                    <form action="{{ route('student.attendance.form') }}" method="GET" class="flex gap-4">
                        <div class="flex-1">
                            <label for="attendance_code" class="block text-sm font-medium text-blue-900 mb-2">Attendance Code</label>
                            <input 
                                type="text" 
                                id="attendance_code" 
                                name="code" 
                                placeholder="Enter 6-digit code (e.g., 47187B)" 
                                class="w-full px-4 py-2 border border-blue-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                required
                                maxlength="6"
                                pattern="[A-Za-z0-9]{6}"
                                title="Please enter a 6-character attendance code"
                            >
                        </div>
                        <div class="flex items-end">
                            <button 
                                type="submit" 
                                class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-md font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                            >
                                <i class="fas fa-check mr-2"></i>
                                Mark Attendance
                            </button>
                        </div>
                    </form>
                    
                    @if(session('error'))
                        <div class="mt-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded">
                            <i class="fas fa-exclamation-triangle mr-2"></i>
                            {{ session('error') }}
                        </div>
                    @endif
                    
                    @if(session('success'))
                        <div class="mt-4 p-3 bg-green-100 border border-green-400 text-green-700 rounded">
                            <i class="fas fa-check-circle mr-2"></i>
                            {{ session('success') }}
                        </div>
                    @endif
                </div>

                @if(count($attendanceSummary) > 0)
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        @foreach($attendanceSummary as $summary)
                            <div class="bg-white border border-gray-200 rounded-lg p-6 shadow-sm">
                                <div class="flex items-center justify-between mb-4">
                                    <h4 class="text-lg font-semibold text-gray-900">{{ $summary['subject']->name }}</h4>
                                    <span class="text-sm text-gray-500">{{ $summary['subject']->code }}</span>
                                </div>
                                
                                <div class="space-y-3">
                                    <div class="flex justify-between">
                                        <span class="text-gray-600">Total Sessions:</span>
                                        <span class="font-medium">{{ $summary['total_sessions'] }}</span>
                                    </div>
                                    
                                    <div class="flex justify-between">
                                        <span class="text-gray-600">Attended:</span>
                                        <span class="font-medium text-green-600">{{ $summary['attended_sessions'] }}</span>
                                    </div>
                                    
                                    <div class="flex justify-between">
                                        <span class="text-gray-600">Attendance Rate:</span>
                                        <span class="font-medium {{ $summary['percentage'] >= 80 ? 'text-green-600' : ($summary['percentage'] >= 60 ? 'text-yellow-600' : 'text-red-600') }}">
                                            {{ $summary['percentage'] }}%
                                        </span>
                                    </div>
                                </div>
                                
                                <div class="mt-4 pt-4 border-t border-gray-200">
                                    <div class="w-full bg-gray-200 rounded-full h-2">
                                        <div class="bg-blue-600 h-2 rounded-full" style="width: {{ $summary['percentage'] }}%"></div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                @else
                    <div class="text-center py-12">
                        <i class="fas fa-clipboard-list text-4xl text-gray-400 mb-4"></i>
                        <h3 class="text-lg font-medium text-gray-900 mb-2">No Attendance Records</h3>
                        <p class="text-gray-600">You haven't attended any sessions yet. Check with your teachers for attendance codes.</p>
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection 